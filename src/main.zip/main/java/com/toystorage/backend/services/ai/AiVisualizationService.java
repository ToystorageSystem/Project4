package com.toystorage.backend.services.ai;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.toystorage.backend.enums.ai.AiIntent;

import lombok.RequiredArgsConstructor;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AiVisualizationService {

    private final ObjectMapper objectMapper;


    // =========================================================
    // BUILD TABLE DATA
    // TẠO DỮ LIỆU BẢNG
    //
    // ENGLISH NOTE:
    // Convert analytics context into table data
    // that the frontend can display directly.
    //
    // GHI CHÚ TIẾNG VIỆT:
    // Chuyển analytics context thành dữ liệu bảng
    // để frontend có thể hiển thị trực tiếp.
    // =========================================================

    public List<Map<String, Object>> buildTableData(
            AiIntent intent,
            Map<String, Object> context
    ) {

        if (
                intent == null
                        || context == null
                        || context.isEmpty()
        ) {

            return List.of();
        }


        return switch (intent) {

            // =================================================
            // SALES
            // BÁN HÀNG
            // =================================================

            case SALES -> extractFirstAvailable(
                    context,
                    "dailySalesTrend",
                    "monthlySalesTrend",
                    "salesSummary"
            );


            // =================================================
            // PRODUCT
            // SẢN PHẨM
            //
            // ENGLISH NOTE:
            // If requestedProductId is provided,
            // return only that product in tableData.
            //
            // GHI CHÚ TIẾNG VIỆT:
            // Nếu user truyền requestedProductId,
            // tableData chỉ trả đúng sản phẩm đó.
            // =================================================

            case PRODUCT ->
                    buildProductTableData(
                            context
                    );


            // =================================================
            // INVENTORY
            // TỒN KHO
            // =================================================

            case INVENTORY -> extractFirstAvailable(
                    context,
                    "inventoryMovement",
                    "slowMovingInventory",
                    "transferRecommendations",
                    "inventoryAnomalies",
                    "inventorySummary"
            );


            // =================================================
            // SUPPLIER
            // NHÀ CUNG CẤP
            // =================================================

            case SUPPLIER -> extractFirstAvailable(
                    context,
                    "supplierPerformance",
                    "suppliers"
            );


            // =================================================
            // PURCHASE ORDER
            // ĐƠN MUA HÀNG
            //
            // ENGLISH NOTE:
            // The actual AI analytics context uses
            // the key "purchaseOrders".
            //
            // GHI CHÚ TIẾNG VIỆT:
            // Context thực tế của AI đang dùng
            // key "purchaseOrders".
            // =================================================

            case PURCHASE_ORDER -> extractFirstAvailable(
                    context,
                    "purchaseOrders",
                    "purchaseOrderAnalytics"
            );


            // =================================================
            // STOCK TRANSFER
            // ĐIỀU CHUYỂN HÀNG
            // =================================================

            case STOCK_TRANSFER -> extractFirstAvailable(
                    context,
                    "stockTransferOperations",
                    "transferOperations",
                    "transfers"
            );


            // =================================================
            // FORECAST
            // DỰ BÁO
            // =================================================

            case FORECAST -> extractFirstAvailable(
                    context,
                    "forecastAnalytics",
                    "forecast"
            );


            // =================================================
            // GENERAL
            // TỔNG QUÁT
            // =================================================

            case GENERAL -> List.of();
        };
    }


    // =========================================================
    // BUILD CHART METADATA
    // TẠO THÔNG TIN BIỂU ĐỒ
    //
    // ENGLISH NOTE:
    // Backend does not render the chart.
    //
    // It only tells the frontend:
    //
    // - chart type
    // - title
    // - data source
    // - X axis
    // - Y axis
    //
    // GHI CHÚ TIẾNG VIỆT:
    // Backend không trực tiếp vẽ biểu đồ.
    //
    // Backend chỉ cung cấp:
    //
    // - loại biểu đồ
    // - tiêu đề
    // - nguồn dữ liệu
    // - trục X
    // - trục Y
    // =========================================================

    public Map<String, Object> buildChartMetadata(
            AiIntent intent,
            Map<String, Object> context
    ) {

        if (
                intent == null
                        || context == null
                        || context.isEmpty()
        ) {

            return Map.of();
        }


        Map<String, Object> chart =
                new LinkedHashMap<>();


        switch (intent) {

            // =================================================
            // SALES
            // BÁN HÀNG
            // =================================================

            case SALES -> {

                chart.put(
                        "type",
                        "LINE"
                );

                chart.put(
                        "title",
                        "Daily Revenue Trend"
                );

                chart.put(
                        "dataSource",
                        "dailySalesTrend"
                );

                chart.put(
                        "xAxis",
                        "period"
                );

                chart.put(
                        "yAxis",
                        "revenue"
                );
            }


            // =================================================
            // PRODUCT
            // SẢN PHẨM
            // =================================================

            case PRODUCT -> {

                chart.put(
                        "type",
                        "BAR"
                );

                chart.put(
                        "title",
                        "Product Sales Performance"
                );

                chart.put(
                        "dataSource",
                        "productPerformance"
                );

                chart.put(
                        "xAxis",
                        "productName"
                );

                chart.put(
                        "yAxis",
                        "revenue"
                );
            }


            // =================================================
            // INVENTORY
            // TỒN KHO
            // =================================================

            case INVENTORY -> {

                chart.put(
                        "type",
                        "BAR"
                );

                chart.put(
                        "title",
                        "Inventory Movement"
                );

                chart.put(
                        "dataSource",
                        "inventoryMovement"
                );

                chart.put(
                        "xAxis",
                        "productName"
                );

                chart.put(
                        "yAxis",
                        "netMovement"
                );
            }


            // =================================================
            // SUPPLIER
            // NHÀ CUNG CẤP
            //
            // ENGLISH NOTE:
            // Actual field returned by supplier analytics:
            // onTimeDeliveryRate
            //
            // GHI CHÚ TIẾNG VIỆT:
            // Field thực tế của supplier analytics là:
            // onTimeDeliveryRate
            // =================================================

            case SUPPLIER -> {

                chart.put(
                        "type",
                        "BAR"
                );

                chart.put(
                        "title",
                        "Supplier Performance"
                );

                chart.put(
                        "dataSource",
                        "supplierPerformance"
                );

                chart.put(
                        "xAxis",
                        "supplierName"
                );

                chart.put(
                        "yAxis",
                        "onTimeDeliveryRate"
                );
            }


            // =================================================
            // PURCHASE ORDER
            // ĐƠN MUA HÀNG
            //
            // ENGLISH NOTE:
            // Runtime analytics returns:
            //
            // dataSource = purchaseOrders
            // yAxis      = receivingProgressPercent
            //
            // GHI CHÚ TIẾNG VIỆT:
            // Dữ liệu runtime thực tế trả:
            //
            // dataSource = purchaseOrders
            // yAxis      = receivingProgressPercent
            // =================================================

            case PURCHASE_ORDER -> {

                chart.put(
                        "type",
                        "BAR"
                );

                chart.put(
                        "title",
                        "Purchase Order Progress"
                );

                chart.put(
                        "dataSource",
                        "purchaseOrders"
                );

                chart.put(
                        "xAxis",
                        "orderCode"
                );

                chart.put(
                        "yAxis",
                        "receivingProgressPercent"
                );
            }


            // =================================================
            // STOCK TRANSFER
            // ĐIỀU CHUYỂN HÀNG
            // =================================================

            case STOCK_TRANSFER -> {

                chart.put(
                        "type",
                        "BAR"
                );

                chart.put(
                        "title",
                        "Stock Transfer Progress"
                );

                chart.put(
                        "dataSource",
                        "stockTransferOperations"
                );

                chart.put(
                        "xAxis",
                        "transferCode"
                );

                chart.put(
                        "yAxis",
                        "receivingProgress"
                );
            }


            // =================================================
            // FORECAST
            // DỰ BÁO
            // =================================================

            case FORECAST -> {

                chart.put(
                        "type",
                        "LINE"
                );

                chart.put(
                        "title",
                        "Product Demand Forecast"
                );

                chart.put(
                        "dataSource",
                        "forecast"
                );

                chart.put(
                        "xAxis",
                        "period"
                );

                chart.put(
                        "yAxis",
                        "forecastQuantity"
                );
            }


            // =================================================
            // GENERAL
            // TỔNG QUÁT
            // =================================================

            case GENERAL -> {

                return Map.of();
            }
        }


        return chart;
    }


    // =========================================================
    // BUILD PRODUCT TABLE DATA
    // TẠO TABLE DATA CHO PRODUCT
    // =========================================================

    private List<Map<String, Object>> buildProductTableData(
            Map<String, Object> context
    ) {

        if (
                context == null
                        || context.isEmpty()
        ) {

            return List.of();
        }


        List<Map<String, Object>> productRows =
                convertToRows(
                        context.get(
                                "productPerformance"
                        )
                );


        Object requestedProductId =
                context.get(
                        "requestedProductId"
                );


        // =====================================================
        // NO PRODUCT PERFORMANCE
        // KHÔNG CÓ PRODUCT PERFORMANCE
        // =====================================================

        if (productRows.isEmpty()) {

            if (requestedProductId != null) {

                return List.of();
            }


            return convertToRows(
                    context.get(
                            "categorySales"
                    )
            );
        }


        // =====================================================
        // GENERAL PRODUCT QUESTION
        // CÂU HỎI PRODUCT TỔNG QUÁT
        // =====================================================

        if (requestedProductId == null) {

            return productRows;
        }


        long targetProductId =
                toLong(
                        requestedProductId
                );


        // =====================================================
        // FIND EXACT PRODUCT
        // TÌM ĐÚNG SẢN PHẨM
        // =====================================================

        for (
                Map<String, Object> row
                : productRows
        ) {

            long productId =
                    getLong(
                            row,
                            "productId"
                    );


            if (
                    productId
                            == targetProductId
            ) {

                return List.of(
                        row
                );
            }
        }


        // ENGLISH NOTE:
        // Never return another product by mistake.
        //
        // GHI CHÚ TIẾNG VIỆT:
        // Không lấy sản phẩm khác để trả nhầm.

        return List.of();
    }


    // =========================================================
    // EXTRACT FIRST AVAILABLE DATA
    // LẤY DỮ LIỆU ĐẦU TIÊN CÓ SẴN
    // =========================================================

    private List<Map<String, Object>> extractFirstAvailable(
            Map<String, Object> context,
            String... keys
    ) {

        if (
                context == null
                        || context.isEmpty()
                        || keys == null
        ) {

            return List.of();
        }


        for (
                String key
                : keys
        ) {

            if (
                    key == null
                            || key.isBlank()
            ) {

                continue;
            }


            Object value =
                    context.get(
                            key
                    );


            if (value == null) {

                continue;
            }


            List<Map<String, Object>> rows =
                    convertToRows(
                            value
                    );


            if (!rows.isEmpty()) {

                return rows;
            }
        }


        return List.of();
    }


    // =========================================================
    // CONVERT VALUE -> TABLE ROWS
    // CHUYỂN VALUE -> DỮ LIỆU BẢNG
    // =========================================================

    private List<Map<String, Object>> convertToRows(
            Object value
    ) {

        if (value == null) {

            return List.of();
        }


        // =====================================================
        // COLLECTION / LIST
        // COLLECTION / DANH SÁCH
        // =====================================================

        if (
                value instanceof Collection<?> collection
        ) {

            List<Map<String, Object>> rows =
                    new ArrayList<>();


            for (
                    Object item
                    : collection
            ) {

                if (item == null) {

                    continue;
                }


                Map<String, Object> row =
                        convertToMap(
                                item
                        );


                if (!row.isEmpty()) {

                    rows.add(
                            row
                    );
                }
            }


            return rows;
        }


        // =====================================================
        // DTO / MAP
        // DTO / MAP
        // =====================================================

        Map<String, Object> map =
                convertToMap(
                        value
                );


        if (map.isEmpty()) {

            return List.of();
        }


        // =====================================================
        // NESTED COLLECTION
        // COLLECTION LỒNG BÊN TRONG
        // =====================================================

        String[] nestedListKeys = {

                "records",
                "items",
                "data",
                "results",

                "products",
                "categories",

                "suppliers",

                "purchaseOrders",

                "transfers",

                "forecasts"
        };


        for (
                String nestedKey
                : nestedListKeys
        ) {

            Object nestedValue =
                    map.get(
                            nestedKey
                    );


            if (
                    nestedValue instanceof Collection<?>
            ) {

                return convertToRows(
                        nestedValue
                );
            }
        }


        return List.of(
                map
        );
    }


    // =========================================================
    // CONVERT OBJECT / DTO -> MAP
    // CHUYỂN OBJECT / DTO -> MAP
    // =========================================================

    private Map<String, Object> convertToMap(
            Object value
    ) {

        if (value == null) {

            return Map.of();
        }


        if (
                value instanceof Map<?, ?> existingMap
        ) {

            Map<String, Object> result =
                    new LinkedHashMap<>();


            for (
                    Map.Entry<?, ?> entry
                    : existingMap.entrySet()
            ) {

                result.put(
                        String.valueOf(
                                entry.getKey()
                        ),
                        entry.getValue()
                );
            }


            return result;
        }


        return objectMapper.convertValue(
                value,
                new TypeReference<Map<String, Object>>() {
                }
        );
    }


    // =========================================================
    // NUMBER HELPERS
    // HÀM HỖ TRỢ XỬ LÝ SỐ
    // =========================================================

    private long getLong(
            Map<?, ?> map,
            String key
    ) {

        if (
                map == null
                        || key == null
        ) {

            return 0L;
        }


        return toLong(
                map.get(
                        key
                )
        );
    }


    private long toLong(
            Object value
    ) {

        if (
                value instanceof Number number
        ) {

            return number.longValue();
        }


        if (value != null) {

            try {

                return Long.parseLong(
                        value.toString()
                );

            } catch (
                    NumberFormatException ignored
            ) {

                return 0L;
            }
        }


        return 0L;
    }
}