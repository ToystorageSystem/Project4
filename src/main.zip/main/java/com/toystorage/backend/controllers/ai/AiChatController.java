package com.toystorage.backend.controllers.ai;

import com.toystorage.backend.dto.request.ai.AiChatRequest;
import com.toystorage.backend.dto.response.ai.AiChatResponse;
import com.toystorage.backend.services.ai.AiChatService;

import jakarta.validation.Valid;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/analytics/ai")
@RequiredArgsConstructor
@PreAuthorize(
        "hasAnyRole('BIZ_STAFF', 'BIZ_MANAGER') "
                + "or "
                + "hasAnyAuthority("
                + "'ROLE_ROLE-BIZ-STAFF', "
                + "'ROLE_ROLE-BIZ-MANAGER'"
                + ")"
)
public class AiChatController {

    private final AiChatService
            aiChatService;


    // =========================================================
    // AI CHAT
    //
    // Business Staff / Business Manager
    //
    // POST:
    //
    // /api/analytics/ai/chat
    //
    // Luồng:
    //
    // User question
    //      ↓
    // Intent Router
    //      ↓
    // Analytics Context
    //      ↓
    // OpenAI nếu đã cấu hình
    //      ↓
    // Fallback nếu AI chưa bật
    // =========================================================

    @PostMapping("/chat")
    public ResponseEntity<AiChatResponse> chat(

            @Valid
            @RequestBody
            AiChatRequest request
    ) {

        AiChatResponse response =
                aiChatService
                        .chat(
                                request
                        );


        return ResponseEntity.ok(
                response
        );
    }
}