package com.toystorage.backend.dto.request.ai;

import jakarta.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiChatRequest {

    @NotBlank(
            message = "Câu hỏi AI không được để trống"
    )
    private String message;


    /**
     * Optional context filters.
     *
     * Có thể dùng sau này để giới hạn dữ liệu
     * AI phân tích theo store / warehouse / product.
     */
    private Long storeId;

    private Long warehouseId;

    private Long productId;
}