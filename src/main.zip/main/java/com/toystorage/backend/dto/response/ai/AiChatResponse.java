package com.toystorage.backend.dto.response.ai;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiChatResponse {

    /**
     * Câu hỏi gốc của người dùng.
     */
    private String question;


    /**
     * Intent mà backend xác định.
     *
     * Ví dụ:
     *
     * INVENTORY
     * SALES
     * PRODUCT
     * PURCHASE_ORDER
     * SUPPLIER
     * STOCK_TRANSFER
     * FORECAST
     * GENERAL
     */
    private String intent;


    /**
     * Câu trả lời tự nhiên từ AI.
     */
    private String answer;


    /**
     * AI provider đã thực sự được gọi hay chưa.
     *
     * false:
     * có thể đang dùng fallback response.
     */
    private Boolean aiGenerated;


    /**
     * Tên model đã sử dụng.
     *
     * null nếu AI chưa được bật.
     */
    private String model;


    /**
     * Dữ liệu analytics backend đã cung cấp
     * cho AI.
     *
     * Giữ dạng generic để mỗi intent có thể
     * trả loại dữ liệu khác nhau.
     */
    private Object analyticsData;


    /**
     * Table data cho frontend.
     *
     * Mỗi row:
     * Map<String, Object>
     */
    private List<Map<String, Object>> tableData;


    /**
     * Metadata gợi ý frontend vẽ chart.
     *
     * Ví dụ:
     *
     * {
     *   "type": "bar",
     *   "xField": "productName",
     *   "yField": "soldQuantity"
     * }
     */
    private Map<String, Object> chartMetadata;


    /**
     * Thời điểm backend tạo response.
     */
    private LocalDateTime generatedAt;
}